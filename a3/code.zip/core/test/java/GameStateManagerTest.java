import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.mygdx.game.states.GameStateManager;
import com.mygdx.game.states.State;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class GameStateManagerTest {

  //testing to ensure the constructor worked through testing of getters
  @Test
  public void StackIsInCorrectOrder() {
    GameStateManager manager = new GameStateManager();
    State exampleState1 = new State(manager){
      @Override
      public void update(float deltaTime) {
        // TODO Auto-generated method stub
        
      }
    
      @Override
      public void render(SpriteBatch spriteBatch) {
        // TODO Auto-generated method stub
        
      }
    
      @Override
      public void dispose() {
        // TODO Auto-generated method stub
        
      }
    };
    State exampleState2 = new State(manager){
      @Override
      public void update(float deltaTime) {
        // TODO Auto-generated method stub
        
      }
    
      @Override
      public void render(SpriteBatch spriteBatch) {
        // TODO Auto-generated method stub
        
      }
    
      @Override
      public void dispose() {
        // TODO Auto-generated method stub
        
      }
    };

    // Push example state
    manager.push(exampleState1);
    manager.push(exampleState2);

    assertEquals(exampleState2, manager.peak());
    manager.pop();
    assertEquals(exampleState1, manager.peak());
  }

}
