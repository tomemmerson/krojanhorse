package com.mygdx.game.sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.states.PlayState;

/**
 * The class which creates a firetruck object to be controlled by the user within the PlayState.
 *
 * @author Cassie Lillystone
 */

public class Firetruck extends Character {

    private int maxWater;
    private int currentWater;
    private boolean selected;
    private float rotation;
    private boolean killedBool;
    private PlayState curState;

    public Firetruck(Vector2 position, int width, int height, Texture texture, int maxHealth, int range, Unit target,
                     int speed, int dps, int maxWater, boolean selected, PlayState playState) {
        super(position, width, height, texture, maxHealth, range, target, speed, dps);
        this.maxWater = maxWater;
        this.currentWater = maxWater;
        this.selected = selected;
        this.killedBool=false;
        this.curState=playState;
    }

    // ##assessment 3: added rotations properly for the fire truck sprites based on movement direction
    /**
     * A method which controllers Firetruck movement depending on the direction input
     * @param dx change in x for movement
     * @param dy change in y for movement
     */
    public void move(int dx, int dy) {
        if (!this.killedBool) {
            float deltaTime = Gdx.graphics.getDeltaTime();
            float modifier = 0.709f;
            if (dx != 0 ^ dy != 0) {
                modifier = 1;
            }
            this.rotation = 0;
            if (dx == 1 & dy == 1) {
                this.rotation = -45;
            } else if (dx == 1 & dy == 0) {
                this.rotation = -90;
            } else if (dx == 1 & dy == -1) {
                this.rotation = -135;
            } else if (dx == 0 & dy == -1) {
                this.rotation = -180;
            } else if (dx == -1 & dy == -1) {
                this.rotation = -225;
            } else if (dx == -1 & dy == 0) {
                this.rotation = -270;
            } else if (dx == -1 & dy == 1) {
                this.rotation = -315;
            }

            // ##assessment 3: set position without diagonal movement being quicker

            float newX = getPosition().x + (dx * this.getSpeed() * deltaTime * modifier);
            float newY = getPosition().y + (dy * this.getSpeed() * deltaTime * modifier);

            if (curState.checkMaskPixel((int) newX + this.getWidth()/2,
                    (int) newY + this.getHeight()/2)) {
                setPosition(newX, newY);
            } else if (curState.checkMaskPixel((int) this.getPosition().x  + this.getWidth()/2,
                    (int) newY + this.getHeight()/2)) {
                setPosition(this.getPosition().x, newY);
            } else if (curState.checkMaskPixel((int) newX + this.getWidth()/2,
                    (int) this.getPosition().y + this.getHeight()/2)) {
                setPosition(newX, this.getPosition().y);
            }
        }
    }

    public int getMaxWater() {
        return maxWater;
    }

    public boolean getKilledBool(){
        return this.killedBool;
    }

    public void setKilledBool(){
        this.killedBool = true;
    }

    public int getCurrentWater() {
        return currentWater;
    }

    public float getRotation(){
        return this.rotation;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setCurrentWater(int currentWater) {
        this.currentWater = currentWater;
    }

    public void updateCurrentWater(int waterUsed) {
        if ((this.currentWater - waterUsed) < 0) {
            this.currentWater = 0;
            return;
        }
        this.currentWater -=  waterUsed;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}