package com.mygdx.game.sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

import java.util.ArrayList;
import java.util.Random;

/**
 * The class which creates the Fortress within the level
 *
 * @author Jordan Spooner
 */
public class Fortress extends Unit {

    private float spawnRate;
    private boolean performAttack;
    private ArrayList<Vector2> alienPositions = new ArrayList<>();
    private int currentPattern;
    private float timeFromAttackStart;
    private int spiralCount;
    private int damage;
    private int range;
    private float delayTimer;
    private ArrayList<Integer> bulletRotations;

    public Fortress(Vector2 position, int width, int height, Texture texture, int maxHealth, float spawnRate, int level) {
        super(position, width, height, texture, maxHealth);
        this.spawnRate = spawnRate;

        this.bulletRotations = new ArrayList<>();
        this.currentPattern = 0;
        this.timeFromAttackStart = 0;
        this.performAttack= true;
        this.spiralCount = 0;
        this.damage = 10;
        this.range = 250;
        this.delayTimer = 3;
    }

    public float getSpawnRate() {
        return this.spawnRate;
    }

    public int getDamage() { return this.damage; }

    public float getRange() { return this.range; }

    public ArrayList<Integer> getBulletRotations() { return this.bulletRotations; }

    public ArrayList<Vector2> getAlienPositions() { return alienPositions; }

    // ##assessment 3: cycle between the attacks fortresses can perform by calling relevant functions, return the bullet directions for the current frame
    // ## also include a short grace period between attacks
    public ArrayList<Integer> randomAttack(){
        float deltaTime = Gdx.graphics.getDeltaTime();
        this.timeFromAttackStart+=deltaTime;
        this.delayTimer+=deltaTime;
        if (this.currentPattern == 0) {
            attackPatternCircle();
        } else if (this.currentPattern == 1) {
            attackPatternSpiral();
        }
        else if (this.currentPattern == 2) {
            attackPatternAlternate();
        }
        return this.bulletRotations;
    }

    // ##assessment 3: creates a ring of 72 projectiles that move outwards
    private void attackPatternCircle(){
        ArrayList<Integer> localBulletRotations = new ArrayList<>();
        if (this.delayTimer>2) {
            if (this.performAttack) {
                this.performAttack = false;
                for (int i = 0; i < 72; i++) {
                    localBulletRotations.add(i * 5);
                }
            } else {
                this.currentPattern = 1;
                this.performAttack = true;
                this.delayTimer = 0;
            }
        }
        this.bulletRotations = localBulletRotations;
    }

    // ##assessment 3: creates a long outwards spiral of bullets
    private void attackPatternSpiral(){
        ArrayList<Integer> localBulletRotations = new ArrayList<>();
        if (this.delayTimer>3) {
            if (this.spiralCount * 0.07 < timeFromAttackStart) {
                localBulletRotations.add(this.spiralCount * 8);
                this.spiralCount += 1;
            }
            if (this.spiralCount > 250) {
                this.spiralCount = 0;
                this.currentPattern = 2;
                this.delayTimer = 0;
            }
        }
        this.bulletRotations=localBulletRotations;
    }

    // ##assessment 3: creates a shorter but harder to dodge interweaving spiral of bullets
    private void attackPatternAlternate(){
        ArrayList<Integer> localBulletRotations = new ArrayList<>();
        if (this.delayTimer>3) {
            if (this.spiralCount * 0.07 < timeFromAttackStart) {
                localBulletRotations.add(this.spiralCount * 60);
                this.spiralCount += 1;
            }
            if (this.spiralCount > 100) {
                this.spiralCount = 0;
                this.currentPattern = 0;
                this.delayTimer = 0;
            }
        }
        this.bulletRotations=localBulletRotations;
    }
}