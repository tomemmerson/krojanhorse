package com.mygdx.game.misc;
import java.util.Random;

public class TetrisShapes {
    public enum Tetrominoe { NoShape, ZShape, SShape, LineShape,
        TShape, SquareShape, LShape, MirroredLShape }

    private Tetrominoe pieceShape;
    private int[][] coords;


    public TetrisShapes() {
        coords = new int[4][2];
        setShape(Tetrominoe.NoShape);
    }

    // ##assessment 3: coordinates table for all the different shapes for where squares are in the pieces
    public void setShape(Tetrominoe shape) {
        int[][][] coordsTable = new int[][][]{
                {{0, 0}, {0, 0}, {0, 0}, {0, 0}},
                {{0, -1}, {0, 0}, {-1, 0}, {-1, 1}},
                {{0, -1}, {0, 0}, {1, 0}, {1, 1}},
                {{0, -1}, {0, 0}, {0, 1}, {0, 2}},
                {{-1, 0}, {0, 0}, {1, 0}, {0, 1}},
                {{0, 0}, {1, 0}, {0, 1}, {1, 1}},
                {{-1, -1}, {0, -1}, {0, 0}, {0, 1}},
                {{1, -1}, {0, -1}, {0, 0}, {0, 1}}
        };
        for (int i = 0; i < 4 ; i++) {
            System.arraycopy(coordsTable[shape.ordinal()],0,coords,0,4);
        }
        pieceShape = shape;
    }

    // ##assessment 3: setter and getter methods
    private void setX(int index, int x) { coords[index][0] = x; }

    private void setY(int index, int y) { coords[index][1] = y; }

    public int x(int index) { return coords[index][0]; }

    public int y(int index) { return coords[index][1]; }

    public Tetrominoe getShape()  { return pieceShape; }

    // ##assessment 3: assign a random piece to a newly created piece
    public void setRandomShape() {
        Random r = new Random();
        int x = Math.abs(r.nextInt()) % 7 + 1;

        Tetrominoe[] values = Tetrominoe.values();
        setShape(values[x]);
    }


    // ##assessment 3: find minimum y coordinates on a piece to help with collision
    public int minY() {
        int m = coords[0][1];
        for (int i=0; i < 4; i++) {
            m = Math.min(m, coords[i][1]);
        }
        return m;
    }

    // ##assessment 3: rotates a piece 90 degrees to the right, doesn't if the piece would rotate into another piece or off canvas
    public TetrisShapes rotateRight() {
        if (pieceShape == Tetrominoe.SquareShape) {

            return this;
        }
        TetrisShapes result = new TetrisShapes();
        result.pieceShape = pieceShape;

        for (int i = 0; i < 4; ++i) {
            result.setX(i, -y(i));
            result.setY(i, x(i));
        }

        return result;
    }
}

