package com.mygdx.game.states;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.Kroy;
import com.mygdx.game.misc.Button;
import com.mygdx.game.misc.TetrisShapes;
import com.mygdx.game.misc.TetrisShapes.Tetrominoe;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;

import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;


public class TetrisState extends State {
    private final int BOARD_WIDTH = 10;
    private final int BOARD_HEIGHT = 20;
    private final int SPRITE_WIDTH = 32;
    private final int SPRITE_HEIGHT = 32;
    private final int MARGIN = 20;
    private final float RENDER_TIME = 0.5f;

    private float frameUpdate = RENDER_TIME;
    private float runtime = 0;
    private float lastPressed = -1;

    private Button quitLevel;
    private Button quitGame;

    private BitmapFont ui;
    private boolean isFallingFinished = false;
    private boolean isPaused = false;
    private boolean lost = false;
    private int lostTime = 0;
    private int score = 0;
    private int curX = 0;
    private int curY = 0;
    private TetrisShapes curPiece;
    private Tetrominoe[] board;
    private Texture tetrisSpritesheet;
    private Texture background;
    private Texture gameBackground;
    private Texture gameBorderBackground;
    private TextureRegion gooseTexture;
    private TextureRegion truckTexture;
    private int bottomCornerX = (Kroy.WIDTH-BOARD_WIDTH*SPRITE_WIDTH)/2;
    private int bottomCornerY = 212;

    // ##assessment 3:constructor for the tetris minigame
    public TetrisState(GameStateManager gsm){
        super(gsm);
        // ##assessment 3: set textures
        background = new Texture("TetrisBackground.png");
        gameBackground = new Texture("pinkPixel.png");
        gameBorderBackground = new Texture("blackPixel.png");

        ui = new BitmapFont(Gdx.files.internal("font.fnt"));
        ui.setColor(Color.WHITE);

        quitLevel = new Button(new Texture("PressedQuitLevel.png"),
                new Texture("NotPressedQuitLevel.png"),350 / 2, 100 / 2,
                new Vector2(30, 30), false, false);

        quitGame = new Button(new Texture("PressedQuitGame.png"),
                new Texture("NotPressedQuitGame.png"), 350 / 2, 100 / 2,
                new Vector2(1920 - 30 - 175, 30), false, false);

        tetrisSpritesheet = new Texture("TetrisSpritesheet.png");
        gooseTexture = new TextureRegion(tetrisSpritesheet, 32,0, 32,32);
        truckTexture = new TextureRegion(tetrisSpritesheet, 0,0, 32,32);
        curPiece = new TetrisShapes();
        board = new Tetrominoe[BOARD_WIDTH * BOARD_HEIGHT];
        clearBoard();

        newPiece();
    }

    // ##assessment 3: perform the frame by frame input handling and method calling
    public void update(float deltaTime) {

        if (quitGame.mouseInRegion()) {
            quitGame.setActive(true);
            if (Gdx.input.isTouched()) {
                Gdx.app.exit();
                System.exit(0);
            }
        } else {
            quitGame.setActive(false);
        }

        if (quitLevel.mouseInRegion()) {
            quitLevel.setActive(true);
            if (Gdx.input.isTouched()) {
                gameStateManager.pop();
            }
        } else {
            quitLevel.setActive(false);
        }
        runtime += deltaTime;
        if (!lost) {
            // ##assessment 3: add a pause button p
            if (isPaused) {
                if (Gdx.input.isKeyJustPressed(Input.Keys.P)) {
                    pause();
                }
                return;
            }
            keyPressed();
            // ##assessment 3: delay for moving pieces and such so pieces don't move every single frame as that would be too fast
            frameUpdate -= Gdx.graphics.getDeltaTime();
            if (frameUpdate < 0) {
                frameUpdate = RENDER_TIME;

                if (isFallingFinished) {
                    isFallingFinished = false;
                    newPiece();
                } else {
                    oneLineDown();
                }
            }
        }
    }
    // ##assessment 3: draw all the textures in correct order from background to foreground
    public void render(SpriteBatch spriteBatch){
        spriteBatch.begin();
        spriteBatch.draw(background,0,0);
        spriteBatch.draw(gameBorderBackground,bottomCornerX-2*MARGIN,bottomCornerY,BOARD_WIDTH*SPRITE_WIDTH+4*MARGIN,BOARD_HEIGHT*SPRITE_HEIGHT+4*MARGIN);

        spriteBatch.draw(gameBackground,bottomCornerX-MARGIN,bottomCornerY+MARGIN,BOARD_WIDTH*SPRITE_WIDTH+2*MARGIN,BOARD_HEIGHT*SPRITE_HEIGHT+2*MARGIN);

        spriteBatch.draw(quitLevel.getTexture(), quitLevel.getPosition().x, quitLevel.getPosition().y,
                quitLevel.getWidth(), quitLevel.getHeight());

        spriteBatch.draw(quitGame.getTexture(), quitGame.getPosition().x, quitGame.getPosition().y,
                quitGame.getWidth(), quitGame.getHeight());


        int boardTop = bottomCornerY+SPRITE_HEIGHT*BOARD_HEIGHT; //20 rows

        // ##assessment 3: draw all the fallen pieces as geese
        for (int i = 0; i < BOARD_HEIGHT; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                Tetrominoe shape = shapeAt(j, BOARD_HEIGHT - i - 1);
                if (shape != Tetrominoe.NoShape) {
                    spriteBatch.draw(gooseTexture,bottomCornerX+j*SPRITE_WIDTH,boardTop-i*SPRITE_HEIGHT);
                }
            }
        }
        // ##assessment 3: draw all the falling pieces as fire trucks
        if (curPiece.getShape() != Tetrominoe.NoShape) {
            for (int i = 0; i < 4; i++) {
                int x = curX + curPiece.x(i);
                int y = curY - curPiece.y(i);
                spriteBatch.draw(truckTexture,bottomCornerX+x*SPRITE_WIDTH,boardTop - (BOARD_HEIGHT-y-1) * SPRITE_HEIGHT);
            }
        }
        // ##assessment 3: if Tetris is lost by pieces reaching the top, show the you lose screen
        if (lost) {
            spriteBatch.draw(new Texture("levelFail.png"), 0, 0);
            if (runtime > lostTime + 5 || Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
                gameStateManager.pop();
            }
        }
        ui.draw(spriteBatch, "Score:"+score, bottomCornerX+ BOARD_WIDTH*SPRITE_WIDTH/2 - 60, bottomCornerY);
        spriteBatch.end();
    }

    // ##assessment 3: change pause state
    private void pause() {
        isPaused = !isPaused;
    }

    // ##assessment 3: return piece at given coordinates
    private Tetrominoe shapeAt(int x, int y) {
        return board[(y * BOARD_WIDTH) + x];
    }

    // ##assessment 3: create a new piece at the top of the board
    // ##assessment 3: if a piece cannot be created at the top since there is a piece that is already there then level is lost
    private void newPiece() {
        curPiece.setRandomShape();
        curX = BOARD_WIDTH / 2 + 1;
        curY = BOARD_HEIGHT - 1 + curPiece.minY();

        if (!tryMove(curPiece, curX, curY)) {

            curPiece.setShape(Tetrominoe.NoShape);
            lost = true;
            lostTime = (int) runtime;
        }
    }


    // ##assessment 3: move the currently falling piece to the lowest it can go
    private void dropDown() {
        int newY = curY;
        while (newY > 0) {

            if (!tryMove(curPiece, curX, newY - 1)) {
                break;
            }
            newY--;
        }
        pieceDropped();
    }

    // ##assessment 3: move current piece down a single tile
    private void oneLineDown() {
        if (!tryMove(curPiece, curX, curY - 1)) {
            pieceDropped();
        }
    }

    // ##assessment 3: set all pieces on the board to have no piece on them for a new game
    private void clearBoard() {
        for (int i = 0; i < BOARD_HEIGHT * BOARD_WIDTH; i++) {
            board[i] = Tetrominoe.NoShape;
        }
    }

    // ##assessment 3: check if any lines should be removed when a piece is placed and create a new piece at the top
    private void pieceDropped() {
        for (int i = 0; i < 4; i++) {
            int x = curX + curPiece.x(i);
            int y = curY - curPiece.y(i);
            board[(y * BOARD_WIDTH) + x] = curPiece.getShape();
        }
        removeFullLines();
        if (!isFallingFinished) {
            newPiece();
        }
    }

    // ##assessment 3: add collision to the pieces to stop them from moving into another piece
    private boolean tryMove(TetrisShapes newPiece, int newX, int newY) {
        for (int i = 0; i < 4; i++) {
            int x = newX + newPiece.x(i);
            int y = newY - newPiece.y(i);

            if (x < 0 || x >= BOARD_WIDTH ||
                    y < 0 || y >= BOARD_HEIGHT) {
                return false;
            }
            if (shapeAt(x, y) != Tetrominoe.NoShape) {
                return false;
            }
        }
        curPiece = newPiece;
        curX = newX;
        curY = newY;
        return true;
    }

    // ##assessment 3: remove all lines which are full with blocks and shift all above rows downwards, add score as well
    private void removeFullLines() {
        int numFullLines = 0;
        for (int i = BOARD_HEIGHT - 1; i >= 0; i--) {
            boolean lineIsFull = true;
            for (int j = 0; j < BOARD_WIDTH; j++) {
                if (shapeAt(j, i) == Tetrominoe.NoShape) {

                    lineIsFull = false;
                    break;
                }
            }
            if (lineIsFull) {
                numFullLines++;
                for (int k = i; k < BOARD_HEIGHT - 1; k++) {
                    for (int j = 0; j < BOARD_WIDTH; j++) {
                        board[(k * BOARD_WIDTH) + j] = shapeAt(j, k + 1);
                    }
                }
            }
        }
        if (numFullLines > 0) {
            score += numFullLines;
            isFallingFinished = true;
            curPiece.setShape(Tetrominoe.NoShape);
        }
    }

    // ##assessment 3: input handling for each method, limit speed of input handling for manageable rotations and movement
    public void keyPressed() {
        if (curPiece.getShape() == Tetrominoe.NoShape) {
            return;
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.P)) {
            pause();
        }
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            dropDown();
        }

        if (runtime - lastPressed > 0.15) {
            if (Gdx.input.isKeyPressed(Input.Keys.A)) {
                tryMove(curPiece, curX - 1, curY);
                lastPressed = runtime;
            } else if (Gdx.input.isKeyPressed(Input.Keys.D)) {
                tryMove(curPiece, curX + 1, curY);
                lastPressed = runtime;
            }
            if (Gdx.input.isKeyPressed(Input.Keys.W)) {
                tryMove(curPiece.rotateRight(), curX, curY);
                lastPressed = runtime;

            } else if (Gdx.input.isKeyPressed(Input.Keys.S)) {
                oneLineDown();
                lastPressed = runtime;
            } else {
                return;
            }
        }
    }


    public void dispose(){
        quitLevel.dispose();
        quitGame.dispose();
    }
}
