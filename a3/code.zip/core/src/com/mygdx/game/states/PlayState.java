package com.mygdx.game.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.Kroy;
import com.mygdx.game.misc.Button;
import com.mygdx.game.misc.Timer;
import com.mygdx.game.sprites.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

/**
 * Implementation of the abstract class State which contains the methods and attributes required to control the
 * gameplay logic for each level as well as rendering to the screen.
 *
 * @author Lucy Ivatt and Bethany Gilmore
 */

public class PlayState extends State {
    private final float SHOOT_SOUND_RATE = 0.1f;

    private Texture background;
    private Texture map;
    private BufferedImage mapCollisionMask;

    private boolean levelLost;
    private boolean levelWon;
    private Preferences saveData;

    private Button quitLevel;
    private Button quitGame;

    private Timer timer;
    private float alienSpawnCountdown;
    private float timeSinceAlienKilled;
    private float timeSinceLastFortressRegen;
    private float timeLimit;
    private float timeTaken;

    private Entity fireStation;
    private Fortress fortress;
    private ArrayList<Vector2> firetruckPositions;
    private int currentTruckIndex;
    public ArrayList<Firetruck> firetrucks = new ArrayList<>();
    private ArrayList<Firetruck> destroyedFiretrucks = new ArrayList<>();
    private ArrayList<Alien> aliens = new ArrayList<>();
    private ArrayList<Projectile> bullets = new ArrayList<>();
    private ArrayList<Projectile> water = new ArrayList<>();

    private BitmapFont ui;
    private BitmapFont healthBars;
    private String level;

    private float soundDelay = SHOOT_SOUND_RATE;
    private float volume = 0.5f;
    private Sound waterShoot = Gdx.audio.newSound(Gdx.files.internal("waterSpray.wav"));
    private Texture skull = new Texture("skull.png");

    private float mapScale = 1.5f;
    private int bottomCornerX = (int) (Kroy.WIDTH/2-(new Texture("Level1.png")).getWidth()*mapScale/2);
    private int bottomCornerY = 212;
    private int tileSize = 16;

    public PlayState(GameStateManager gsm, int levelNumber) {
        super(gsm);

        background = new Texture("BackgroundV2.png");

        quitLevel = new Button(new Texture("PressedQuitLevel.png"),
                new Texture("NotPressedQuitLevel.png"),350 / 2, 100 / 2,
                new Vector2(30, 30), false, false);

        quitGame = new Button(new Texture("PressedQuitGame.png"),
                new Texture("NotPressedQuitGame.png"), 350 / 2, 100 / 2,
                new Vector2(1920 - 30 - 175, 30), false, false);

        level = Integer.toString(levelNumber); // Used as a key when saving level progress

        levelLost = false;
        levelWon = false;

        saveData = Gdx.app.getPreferences("Kroy");

        ui = new BitmapFont(Gdx.files.internal("font.fnt"));
        ui.setColor(Color.DARK_GRAY);

        healthBars = new BitmapFont();

        alienSpawnCountdown = 0;
        timeSinceLastFortressRegen = 0;
        timeSinceAlienKilled = -1;

        // ##assessment 3: Adding patrol aliens with random health and movement through way points
        for (int alienIter = 0; alienIter < 5; alienIter++) {
            Texture alienTexture = new Texture("alien.gif");
            Vector2 coordinate = new Vector2(bottomCornerX + 250, bottomCornerY + 250);
            Random rand = new Random();
            int health = 30 + rand.nextInt(60);
            Vector2[] waypoints = new Vector2[4];
            for (int i = 0; i < 4; i++) {
                waypoints[i] = new Vector2(coordinate.x + rand.nextInt(450), coordinate.y + rand.nextInt(450));
            }

            Alien alien = new Alien(coordinate, 32, 32, alienTexture, health,
                    250, null, 1, 5 + rand.nextInt(15), waypoints, 0.5f);

            aliens.add(alien);
        }


        currentTruckIndex = 0;


        // ## assessment 3: initialised the levels much better without hundreds of lines worth of obstacle creation
        // ## each level initialises its own fire trucks, alien patrols and fortress positions with fortresses having unique sprites
        // ## and levels are set to unique maps
        if (levelNumber == 1) {
            Vector2[] truckPos = { new Vector2(6, 10), new Vector2(8, 10), new Vector2(10, 10), new Vector2(12, 10) };
            firetruckPositions = createLevelFiretruckPositions(truckPos);
            timeLimit = 90;
            this.map = new Texture("Level1.png");
            try {
                // Read in file (can cause error if file not found)
                this.mapCollisionMask = ImageIO.read(Gdx.files.internal("Level1Mask.bmp").read());
            } catch (IOException e) {
                System.out.println(e.toString());
            }
            this.fireStation = createLevelFirestation("FireStation.png", 12, 5);
            this.fortress = createLevelFortress("Level1Fortress.png", 32, 32, 500);
        }

        else if (levelNumber == 2) {
            Vector2[] truckPos = {new Vector2(8, 3), new Vector2(10, 2), new Vector2(12, 3), new Vector2(14, 2)};
            firetruckPositions = createLevelFiretruckPositions(truckPos);
            timeLimit = 120;
            this.map = new Texture("Level2.png");
            try {
                // Read in file (can cause error if file not found)
                this.mapCollisionMask = ImageIO.read(Gdx.files.internal("Level2Mask.bmp").read());
            } catch (IOException e) {
                System.out.println(e.toString());
            }
            this.fireStation = createLevelFirestation("FireStation.png", 1, 2);
            this.fortress = createLevelFortress("Level2Fortress.png", 38, 40, 600);
        }

        else if (levelNumber == 3) {
            Vector2[] truckPos = {new Vector2(8, 3), new Vector2(10, 2), new Vector2(12, 3), new Vector2(14, 2)};
            firetruckPositions = createLevelFiretruckPositions(truckPos);
            timeLimit = 90;
            this.map = new Texture("Level3.png");
            try {
                // Read in file (can cause error if file not found)
                this.mapCollisionMask = ImageIO.read(Gdx.files.internal("Level3Mask.bmp").read());
            } catch (IOException e) {
                System.out.println(e.toString());
            }
            this.fireStation = createLevelFirestation("FireStation.png", 0, 3);
            this.fortress = createLevelFortress("Level3Fortress.png", 21, 31, 700);
        }

        else if (levelNumber == 4) {
            Vector2[] truckPos = {new Vector2(4, 10), new Vector2(6, 10), new Vector2(8, 10), new Vector2(10, 10)};
            firetruckPositions = createLevelFiretruckPositions(truckPos);
            timeLimit = 120;
            this.map = new Texture("Level4.png");
            try {
                // Read in file (can cause error if file not found)
                this.mapCollisionMask = ImageIO.read(Gdx.files.internal("Level4Mask.bmp").read());
            } catch (IOException e) {
                System.out.println(e.toString());
            }
            this.fireStation = createLevelFirestation("FireStation.png", 3, 3);
            this.fortress = createLevelFortress("Level4Fortress.png", 40, 41, 800);
        }

        else if (levelNumber == 5) {
            Vector2[] truckPos = {new Vector2(4, 11), new Vector2(6, 11), new Vector2(8, 11), new Vector2(10, 11)};
            firetruckPositions = createLevelFiretruckPositions(truckPos);
            timeLimit = 90;
            this.map = new Texture("Level5.png");
            try {
                // Read in file (can cause error if file not found)
                this.mapCollisionMask = ImageIO.read(Gdx.files.internal("Level5Mask.bmp").read());
            } catch (IOException e) {
                System.out.println(e.toString());
            }
            this.fireStation = createLevelFirestation("FireStation.png", 2, 2);
            this.fortress = createLevelFortress("Level5Fortress.png", 38, 27, 900);
        }

        else if (levelNumber == 6) {
            Vector2[] truckPos = {new Vector2(6, 11), new Vector2(8, 10), new Vector2(10, 10), new Vector2(12, 8)};
            firetruckPositions = createLevelFiretruckPositions(truckPos);
            timeLimit = 120;
            this.map = new Texture("Level6.png");
            try {
                // Read in file (can cause error if file not found)
                this.mapCollisionMask = ImageIO.read(Gdx.files.internal("Level6Mask.bmp").read());
            } catch (IOException e) {
                System.out.println(e.toString());
            }
            this.fireStation = createLevelFirestation("FireStation.png", 20, 11);
            this.fortress = createLevelFortress("Level6Fortress.png", 20, 25, 1200);
        }

        // ##assessment 3: rework collision system to be image-based and use a mask: create buffered image off mask

        // ##assessment 3: now adding all fire trucks to an array rather than manual object specific accessing
        firetrucks.add(new Firetruck(firetruckPositions.get(0), 25, 25, new Texture("truck.png"), 200, 185, null, 100,  2,
                250, true, this));
        firetrucks.add(new Firetruck(firetruckPositions.get(1), 25, 25, new Texture("truck.png"), 180, 200, null, 125, 2,
                200, false, this));
        firetrucks.add(new Firetruck(firetruckPositions.get(2), 25, 25, new Texture("truck.png"), 160, 215, null, 150, 2,
                150, false, this));
        firetrucks.add(new Firetruck(firetruckPositions.get(3), 25, 25, new Texture("truck.png"), 140, 230, null, 200, 2,
                100, false, this));

        timer = new Timer(timeLimit);
    }

    // ##assessment 3: fire trucks, firestation and fortress positions now assigned through functions with the tile numbers as parameters
    public ArrayList<Vector2> createLevelFiretruckPositions(Vector2[] truckAdjustments) {
        firetruckPositions = new ArrayList<>();
        for (Vector2 i : truckAdjustments) {
            firetruckPositions.add(new Vector2(bottomCornerX + i.x * tileSize, bottomCornerY + i.y * tileSize)); }

        return firetruckPositions; }


    public Entity createLevelFirestation(String firestationTexture, int xTiles, int yTiles) {
        Entity fireStation = new Entity(new Vector2(bottomCornerX + xTiles * tileSize, bottomCornerY + yTiles *tileSize), 4*tileSize, 4*tileSize,
                new Texture(firestationTexture));

        return fireStation; }


    public Fortress createLevelFortress(String fortressTexture, int xTiles, int yTiles, int fortressHealth){
        Fortress fortress = new Fortress(new Vector2(bottomCornerX + xTiles*tileSize, bottomCornerY + yTiles*tileSize), 4*tileSize, 4*tileSize,
                new Texture(fortressTexture), fortressHealth, 1.5f, 1);

        return fortress; }

    /**
     * The game logic which is executed due to specific user inputs. Is called in the update method.
     */
    public void handleInput() {
        if (!levelWon && !levelLost) {
            // Checks for hover and clicks on the 2 buttons located on the play screen.
            if (quitGame.mouseInRegion()) {
                quitGame.setActive(true);
                if (Gdx.input.isTouched()) {
                    Gdx.app.exit();
                    System.exit(0);
                }
            } else {
                quitGame.setActive(false);
            }

            if (quitLevel.mouseInRegion()) {
                quitLevel.setActive(true);
                if (Gdx.input.isTouched()) {
                    gameStateManager.pop();
                }
            } else {
                quitLevel.setActive(false);
            }

            // If the user presses the space bar or the mouse buttons, creates Projectile instance if the selected firetruck has water remaining
            // Then adds this to the water ArrayList and removes 1 water from the firetrucks tank.
            // ##assessment 3: sound bug for overlapping previous fire sound removed and now has new texture. Only fires now whilst truck is alive

            soundDelay -= Gdx.graphics.getDeltaTime();
            for (Firetruck firetruck : firetrucks) {
                if (!firetruck.getKilledBool()) {
                    if ((Gdx.input.isKeyPressed(Input.Keys.SPACE) || Gdx.input.isTouched()) && firetruck.isSelected() && firetruck.getCurrentWater() > 0) {
                        float tempY = firetruck.getPosition().y + firetruck.getHeight() / 2;
                        float tempX = firetruck.getPosition().x + firetruck.getWidth() / 2;
                        Texture waterTexture = new Texture("blue.png");
                        Vector2 targetPos = new Vector2((float) Gdx.input.getX() / (float) Gdx.graphics.getWidth() * Kroy.WIDTH, (1 - (float) Gdx.input.getY() / (float) Gdx.graphics.getHeight()) * Kroy.HEIGHT);
                        Projectile drop = new Projectile(new Vector2(tempX, tempY), 5, 5, waterTexture, targetPos, 5, firetruck.getDamage(), firetruck.getRange());
                        water.add(drop);
                        if (saveData.getBoolean("effects") && soundDelay <= 0) {
                            soundDelay = SHOOT_SOUND_RATE;
                            Random r = new Random();
                            float randomPitch = 0.8f + r.nextFloat() * (1.2f - 0.8f);
                            waterShoot.play(volume, randomPitch, 0);
                        }
                        firetruck.updateCurrentWater(1);
                    }
                }
            }

            // Opens pause menu if user hits escape
            if (Gdx.input.isKeyPressed(Input.Keys.ESCAPE)) {
                gameStateManager.push(new OptionState(gameStateManager));
            }

            // Switches active firetruck if the mouse clicks within another selectable firetruck.
            Vector2 mousePos = new Vector2((float) Gdx.input.getX() / (float) Gdx.graphics.getWidth() * Kroy.WIDTH, (1 - (float) Gdx.input.getY() / (float) Gdx.graphics.getHeight()) * Kroy.HEIGHT);
            if (Gdx.input.isTouched()) {
                for (Firetruck truck : firetrucks) {
                    if (!truck.getKilledBool()) {
                        if (mousePos.x >= (truck.getPosition().x) && mousePos.x <= (truck.getPosition().x + truck.getWidth())
                                && mousePos.y >= (truck.getPosition().y) && mousePos.y <= (truck.getPosition().y
                                + truck.getHeight())) {
                            for (Firetruck clearTruck : firetrucks) {
                                clearTruck.setSelected(false);
                            }
                            currentTruckIndex = firetrucks.indexOf(truck);
                            truck.setSelected(true);
                        }
                    }
                }
            }
            // ##assessment 3: now added being able to swap between firetrucks using number keys
            boolean swappedTemp = false;
            int[] inputKeys = {Input.Keys.NUM_1,Input.Keys.NUM_2,Input.Keys.NUM_3,Input.Keys.NUM_4};
            for (int i=0; i<inputKeys.length;i++){
                if (Gdx.input.isKeyJustPressed(inputKeys[i]) && !firetrucks.get(i).getKilledBool()) {
                    if (firetrucks.get(i).getCurrentHealth() > 0) {
                        currentTruckIndex = i;
                        swappedTemp = true;
                    }
                }
            }
            if (swappedTemp && !firetrucks.get(currentTruckIndex).getKilledBool()) {
                for (Firetruck clearTruck : firetrucks) {
                    clearTruck.setSelected(false);
                }
                firetrucks.get(currentTruckIndex).setSelected(true);
            }
            // Changes which truck is moving and calls the truckMovement() method with the selected truck as input.
            truckMovement(firetrucks.get(currentTruckIndex));
            // Checks if user presses ENTER when game is over and takes them back to level select.
        }

        else if (Gdx.input.isKeyJustPressed(Input.Keys.ENTER)) {
            gameStateManager.set(new LevelSelectState(gameStateManager));
        }
    }

    /**
     * The function that returns the red component of a colour at a certain coordinate of the collision mask
     * for collision checking.
     * @param x the x coordinate in the image.
     * @param y the y coordinate in the image.
     * @return (Int) red component of the colour of the pixel that was asked for.
     * @throws IOException exception thrown in-case the collision mask file hasn't been found.
     */
    private int getMaskPixelColour(int x, int y) throws IOException {
        // Image pixel referencing standards was flipped
        y = this.mapCollisionMask.getHeight() - y;

        // Get the color of a pixel (only 2 colours are 0 and 255 (rgb))
        int color = this.mapCollisionMask.getRGB(x, y);

        // Checks red component since r=g=b in a collision mask
        return (color & 0x00ff0000) >> 16;
    }

    /**
     * Determines if the given pixel is white for collision checking, handling any I/O errors.
     * @param x the x coordinate of the pixel.
     * @param y the y coordinate of the pixel.
     * @return (Boolean) if the given pixel is white.
     */
    public boolean checkMaskPixel(int x, int y) {
        try {
            // Return true if on road (pixel value is > 0)
            return getMaskPixelColour((int) ((x - bottomCornerX) / mapScale),
                    (int) ((y - bottomCornerY) / mapScale)) > 0;
        } catch (Exception e) {
            // Catch exceptions
            return false;
        }
    }

    /**
     * Updates the game logic before the next render() is called
     * @param deltaTime the amount of time which has passed since the last render() call
     */
    @Override
    public void update(float deltaTime) {

        // Calls input handler and updates timer each tick of the game.
        handleInput();
        timer.update();

        // ##assessment 3: added fortress attack patterns using an array of what rotation bullets should travel in
        // ## add all of these projectiles to the bullets array for all current bullets.
        fortress.randomAttack();
        ArrayList<Integer> bulletRotations = fortress.getBulletRotations();
        if (bulletRotations != null) {
            for (Integer bulletRotation : bulletRotations) {
                float xPos = fortress.getPosition().x + fortress.getWidth()*mapScale / 2 + fortress.getWidth()/3* (float) Math.cos(bulletRotation);
                float yPos = fortress.getPosition().y + fortress.getHeight()*mapScale / 2 + fortress.getHeight()/3*(float) Math.sin(bulletRotation);
                float xTarget = xPos + fortress.getRange() * (float) Math.cos(bulletRotation);
                float yTarget = yPos + fortress.getRange() * (float) Math.sin(bulletRotation);
                Projectile bullet = new Projectile(new Vector2(xPos, yPos), 5, 5,
                        new Texture("red.png"), new Vector2(xTarget, yTarget), 0.5f, fortress.getDamage(), fortress.getRange());
                bullets.add(bullet);
            }
        }

        // Updates aliens and attacks firetruck if there is a firetruck in range and the Aliens attack cool down is over.
        // Adds the created bullet projectile to the ArrayList bullets
        for (Alien alien : aliens) {
            alien.update();
            alien.truckInRange(firetrucks);
            if (alien.getTimeSinceAttack() >= alien.getAttackCooldown()) {
                if (alien.hasTarget()) {
                    Projectile bullet = new Projectile(new Vector2(alien.getPosition().x + alien.getWidth() / 2, alien.getPosition().y + alien.getHeight() / 2), 5, 5,
                            new Texture("red.png"), (new Vector2(alien.getTarget().getPosition().x, alien.getTarget().getPosition().y)), 0.25f, alien.getDamage(), fortress.getRange());
                    bullets.add(bullet);
                    alien.resetTimeSinceAttack();
                }
            }
            alien.updateTimeSinceAttack(deltaTime);
        }
        alienSpawnCountdown -= deltaTime;
        timeSinceAlienKilled -= deltaTime;



        // Respawns an alien as long as the spawn cooldown is over and enough time has passed since the
        // user killed an alien.
        if (alienSpawnCountdown <= 0 && timeSinceAlienKilled <= 0) {
            spawnAlien();
            alienSpawnCountdown = fortress.getSpawnRate();
            timeSinceAlienKilled = 0;
        }
        // Updates all bullets each tick, checks if bullet collides with firetruck and then removes health from the
       // firetruck. If a firetruck is destroyed, checks if all have been destroyed and then activates game over screen.
        // ##assessment 3: now bullets despawn when hitting only alive firetrucks
        for (Projectile bullet : new ArrayList<>(bullets)) {
            bullet.update();

            for (Firetruck truck : new ArrayList<>(firetrucks)) {
                if (bullet.hitUnit(truck)) {
                    if (!truck.getKilledBool()) {
                        truck.takeDamage(bullet.getDamage());
                        bullets.remove(bullet);
                    }
                    if ((truck.getCurrentHealth() <= 0 && !truck.getKilledBool())) {
                        truck.setSelected(false);
                        truck.setKilledBool();
                        destroyedFiretrucks.add(truck);
                        if(destroyedFiretrucks.size() == 4) {
                            levelLost = true;
                            timeTaken = timer.getTime();
                        }

                    }
                }
            }
        }

        // Refills firetrucks tank if truck reaches the fire station.
        // ##assessment 3: now also heals and has a pythagorean range to it rather than needing to be inside the station sprite
        // ## the effects now build over a short period of time rather than being instantaneous
        for (Firetruck truck : firetrucks) {
            if (!truck.getKilledBool()){
                int tempXSquared = (int) Math.pow(truck.getPosition().x - fireStation.getPosition().x, 2);
                int tempYSquared = (int) Math.pow(truck.getPosition().y - fireStation.getPosition().y, 2);
                if (Math.sqrt(tempXSquared + tempYSquared) < 150){
                    if (truck.getCurrentWater()<truck.getMaxWater()) {
                        truck.setCurrentWater(truck.getCurrentWater()+1);
                    }
                    if (truck.getCurrentHealth()<truck.getMaxHealth()) {
                        truck.setCurrentHealth(truck.getCurrentHealth()+1);
                    }
                }
            }
        }

        // Updates all water drops each tick, if the drop reaches a certain distance then it is deleted. Otherwise,
        // Checks if drop collides with alien/fortress and then removes health from it if so. If alien dies, removes it
        // and adds its coordinates back to the fortresses potential spawn locations. If fortress reaches 0 then
        // game win screen is called and level progress saved.
        // Also checks if projectiles go outside of map range and disposes of them.

        int xMin = 580;
        int xMax = 1340;
        int yMin = 210;
        int yMax = 970;

        for (Projectile bullet : new ArrayList<>(bullets)){
            bullet.update();
            if (bullet.getLength() > bullet.getMaxLength()
                    || bullet.getPosition().x < xMin
                    || bullet.getPosition().x > xMax
                    || bullet.getPosition().y < yMin
                    || bullet.getPosition().y > yMax) {
                bullet.dispose();
                bullets.remove(bullet);
            }
        }

        for (Projectile drop : new ArrayList<>(water)) {
            drop.update();
            if (drop.getLength() > drop.getMaxLength()
                    || drop.getPosition().x < xMin
                    || drop.getPosition().x > xMax
                    || drop.getPosition().y < yMin
                    || drop.getPosition().y > yMax) {
                drop.dispose();
                water.remove(drop);
            }
            for (Alien alien : new ArrayList<>(aliens)) {
                if (drop.hitUnit(alien)) {
                    alien.takeDamage(drop.getDamage());
                    water.remove(drop);
                    if (alien.getCurrentHealth() == 0) {
                        fortress.getAlienPositions().add(alien.getPosition());
                        alien.dispose();
                        aliens.remove(alien);
                        timeSinceAlienKilled = fortress.getSpawnRate();
                    }
                }
            }
            // ##assessment 3: water now disposed of when hitting the fortress as to not do ludicrous and random amounts of damage as it pierces through
            if (drop.hitUnit(fortress)) {
                fortress.takeDamage(drop.getDamage());
                water.remove(drop);
                if (fortress.getCurrentHealth() == 0) {
                    levelWon = true;
                    timeTaken = timer.getTime();
                    saveData.putBoolean(level, true);
                    saveData.flush();
                }
            }
        }

        // ##assessment 3:  Regenerates fortress health each second at a rate fitting for the damage trucks deal
        if(timeSinceLastFortressRegen <= 0) {
            fortress.addHealth(5);
            timeSinceLastFortressRegen = 1;
        }
        timeSinceLastFortressRegen -= deltaTime;

        // If the time is greater than the time limit, calls end game state.
        if (timer.getTime() > timeLimit) {
            levelLost = true;
        }

        // Forces user back to level select screen, even without needing to press ENTER after 4 seconds.
        if (timer.getTime() > timeLimit + 4) {
            gameStateManager.set(new LevelSelectState(gameStateManager));
        }

        // Speeds up the background music when the player begins to run out of time.
        if ((14 < timeLimit - timer.getTime()) && (timeLimit - timer.getTime() < 16)){
            Kroy.INTRO.setPitch(Kroy.ID, 2f);
        }
    }

    /**
     * Used to draw elements onto the screen.
     * @param spriteBatch a container for all elements which need rendering to the screen.
     */
    @Override
    public void render(SpriteBatch spriteBatch) {
        spriteBatch.begin();

        // Draws background and map onto play screen
        spriteBatch.draw(background, 0, 0, Kroy.WIDTH, Kroy.HEIGHT);
        spriteBatch.draw(map, bottomCornerX, bottomCornerY, map.getWidth()*mapScale, map.getHeight()*mapScale);

        // Draws buttons onto play screen
        spriteBatch.draw(quitLevel.getTexture(), quitLevel.getPosition().x, quitLevel.getPosition().y,
                quitLevel.getWidth(), quitLevel.getHeight());

        spriteBatch.draw(quitGame.getTexture(), quitGame.getPosition().x, quitGame.getPosition().y,
                quitGame.getWidth(), quitGame.getHeight());


        // Draws Firetrucks to the screen, along with their water amount
        // ##assessment 3: if the firetrucks die, now display a blue skull icon
        for (Firetruck truck : firetrucks) {
            if (!truck.getKilledBool()) {
                spriteBatch.draw(new TextureRegion(truck.getTexture()), truck.getPosition().x, truck.getPosition().y,
                        truck.getWidth() / 2, truck.getHeight() / 2,
                        truck.getWidth(), truck.getHeight(), mapScale / 2, mapScale / 2, truck.getRotation());

                healthBars.draw(spriteBatch, "Water: " + truck.getCurrentWater(), truck.getPosition().x,
                        truck.getPosition().y + truck.getHeight() + 10);
            }
            else {
                spriteBatch.draw(skull, truck.getPosition().x, truck.getPosition().y, truck.getWidth()*mapScale, truck.getHeight()*mapScale);
            }
        }
        // Draw Fire Station
        spriteBatch.draw(fireStation.getTexture(),
                fireStation.getPosition().x, fireStation.getPosition().y,
                fireStation.getWidth()*mapScale,fireStation.getHeight()*mapScale);


        // Draw Fortresses to the screen, showing their hp
        // ##assessment 3: now drawing health in correct position as red
        spriteBatch.draw(fortress.getTexture(), fortress.getPosition().x, fortress.getPosition().y,
                fortress.getWidth()*mapScale,fortress.getHeight()*mapScale);
        healthBars.setColor(Color.RED);
        healthBars.draw(spriteBatch, "HP: " + fortress.getCurrentHealth(), fortress.getPosition().x+ fortress.getWidth()/3,
                fortress.getPosition().y + fortress.getHeight()*mapScale);


        // Draw Aliens and their health
        for (Alien alien : aliens) {
            spriteBatch.draw(alien.getTexture(), alien.getPosition().x, alien.getPosition().y, alien.getWidth()*mapScale/2,
                    alien.getHeight()*mapScale/2);
            healthBars.draw(spriteBatch, "HP: " + alien.getCurrentHealth(), alien.getPosition().x,
                    alien.getPosition().y + alien.getHeight() + 10);
        }
        healthBars.setColor(Color.WHITE);

        // Projectiles
        for (Projectile bullet : bullets) {
            spriteBatch.draw(bullet.getTexture(), bullet.getPosition().x, bullet.getPosition().y, bullet.getWidth()*mapScale/2,
                    bullet.getHeight()*mapScale/2);
        }
        for (Projectile drop : water) {
            spriteBatch.draw(drop.getTexture(), drop.getPosition().x, drop.getPosition().y, drop.getWidth()*mapScale/2,
                    drop.getHeight()*mapScale/2);
        }

        timer.drawTime(spriteBatch, ui);
        ui.setColor(Color.WHITE);

        // Gives user 15 second warning as time limit approaches.
        if ((timeLimit - 15) < timer.getTime() && timer.getTime() < (timeLimit - 10)) {
            ui.draw(spriteBatch, "The firestation is being attacked \n You have 15 seconds before it's destroyed!",
                    50, 1020);
        }

        // Draws UI Text onto the screen

        for (int i=0; i<firetrucks.size();i++){
            ui.setColor(Color.DARK_GRAY);
            String text = "Health: "+firetrucks.get(i).getCurrentHealth();
            if (firetrucks.get(i).getKilledBool()){
                text = "Dead";
            }
            if (i == currentTruckIndex){
                ui.setColor(Color.BLUE);
            }
            ui.draw(spriteBatch, "Truck "+(i+1)+ " | " + text, 70+(i*476),
                    Kroy.HEIGHT - 920);
        }
        ui.setColor(Color.DARK_GRAY);

        // If end game reached, draws level fail or level won images to the screen
        if (levelLost) {
            spriteBatch.draw(new Texture("levelFail.png"), 0, 0);
            Kroy.INTRO.setPitch(Kroy.ID, 1f);
        }

        else if (levelWon) {
            spriteBatch.draw(new Texture("LevelWon.png"), 0, 0);
            Kroy.INTRO.setPitch(Kroy.ID, 1f);
        }
        spriteBatch.end();
    }

    /**
     * Used to dispose of all textures, music etc. when no longer required to avoid memory leaks
     */
    @Override
    public void dispose() {
        background.dispose();
        map.dispose();
        quitLevel.dispose();
        quitGame.dispose();
        waterShoot.dispose();

        for (Firetruck firetruck : firetrucks) {
            firetruck.dispose();
        }

        for (Alien alien : aliens) {
            alien.dispose();
        }

        for (Firetruck firetruck : destroyedFiretrucks) {
            firetruck.dispose();
        }

        for (Projectile bullet : bullets) {
            bullet.dispose();
        }

        for (Projectile drop : water) {
            drop.dispose();
        }

        fireStation.dispose();
        fortress.dispose();
    }

    // ##assessment 3: simplified the truck movement greatly from previous implementation
    /**
     * Used to call the correct method to move the the current truck's position
     * @param truck the truck which is currently selected
     */
    public void truckMovement(Firetruck truck) {
        if (!truck.getKilledBool()){
            int dx, dy;
            dx = 0;
            dy = 0;
            boolean hasMoved = false;
            truck.setTexture(new Texture("truck.png"));
            if (Gdx.input.isKeyPressed(Input.Keys.W)) { dy++; hasMoved=true;}
            if (Gdx.input.isKeyPressed(Input.Keys.S)) { dy--; hasMoved=true;}
            if (Gdx.input.isKeyPressed(Input.Keys.A)) { dx--; hasMoved=true;}
            if (Gdx.input.isKeyPressed(Input.Keys.D)) { dx++; hasMoved=true; }
            if (hasMoved){ truck.move(dx, dy);}
            }
        }

    /**
     * Used to spawn the Aliens around the fortress by accessing the spawnRate and alienPositions stored within
     * the fortress object.
     */
    public void spawnAlien() {
        Random rand = new Random();
        if (fortress.getAlienPositions().size() > 0) {
            Vector2 coordinate = fortress.getAlienPositions().get(rand.nextInt(fortress.getAlienPositions().size()));

            Texture alienTexture = new Texture("alien.gif");
            int health = 30 + rand.nextInt(60);
            Vector2[] waypoints = new Vector2[]{new Vector2(coordinate.x, coordinate.y),
                    new Vector2(coordinate.x, coordinate.y + 30) };
            Alien alien = new Alien(coordinate, 32, 32, alienTexture, health,
                    250, null, 1, 5 + rand.nextInt(15), waypoints, 1f);
            aliens.add(alien);
            fortress.getAlienPositions().remove(coordinate);
        }
    }
}
