package com.mygdx.game.states;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.mygdx.game.Kroy;
import com.mygdx.game.misc.Button;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * An implementation of the abstract class State which controls the Level Select Screen.
 *
 * @author Lucy Ivatt
 * @since 11/1/2020
 */

public class LevelSelectState extends State{

    private Texture background;
    private Button level1;
    private Button level2;
    private Button level3;
    private Button level4;
    private Button level5;
    private Button level6;
    private Button level7;
    private Button back;
    private ArrayList<Button> buttons;
    private Preferences saveData;
    private Sound click = Gdx.audio.newSound(Gdx.files.internal("click.wav"));
    private Sound honk = Gdx.audio.newSound((Gdx.files.internal("honk.wav")));

    protected LevelSelectState(GameStateManager gameStateManager) {
        super(gameStateManager);

        // ##assessment 3: added new level buttons
        background = new Texture("LevelSelectBackground.png");
        saveData = Gdx.app.getPreferences("Kroy");

        back = new Button(new Texture("backbutton2.png"), new Texture("backbutton1.png"),
                100, 100, new Vector2(30, 960), false, false);

        level1 = new Button(new Texture("PressedBlue1.png"), new Texture("NotPressedBlue1.png"),
                350, 100, new Vector2(Kroy.WIDTH / 2 - 350 / 2 - 100 - 350, 400), false,
                false);

        level2 = new Button(new Texture("CentralGrey.png"), new Texture("CentralGrey.png"),
                350, 100, new Vector2(Kroy.WIDTH / 2 - 350 / 2, 400), false, true);

        level3 = new Button(new Texture("MinsterGrey.png"), new Texture("MinsterGrey.png"),
                350, 100, new Vector2(Kroy.WIDTH / 2 + 350 / 2 + 100, 400), false,
                true);

        level4 = new Button(new Texture("MazeGrey.png"), new Texture("MazeGrey.png"),
                350, 100, new Vector2(Kroy.WIDTH / 2 - 350 / 2 - 100 - 350, 200), false,
                true);

        level5 = new Button(new Texture("CliffordGrey.png"), new Texture("CliffordGrey.png"),
                350, 100, new Vector2(Kroy.WIDTH / 2 - 350 / 2, 200), false, true);

        level6 = new Button(new Texture("RacecourseGrey.png"), new Texture("RacecourseGrey.png"),
                350, 100, new Vector2(Kroy.WIDTH / 2 + 350 / 2 + 100, 200), false,
                true);
        level7 = new Button(new Texture("bonus_pressed.png"), new Texture("Notbonus_pressed.png"),
                350, 95, new Vector2(Kroy.WIDTH / 2 - 350 / 2 , 30), false,
                false);

        buttons = new ArrayList<>(Arrays.asList(level1, level2, level3, level4, level5, level6, level7, back));
    }

    /**
     * The game logic which is executed due to specific user inputs. Is called in the update method.
     *
     * Checks if mouse is hovering over a button and plays the animation accordingly as well as checking for
     * mouse clicks which will activate the function of the button.
     */
    public void handleInput() {
        if (back.mouseInRegion()) {
            back.setActive(true);
            if (Gdx.input.isTouched()) {
                if (saveData.getBoolean("effects")) {
                    click.play();
                }
                gameStateManager.pop();
            }
        }
        else if (level7.mouseInRegion()){
            if (Gdx.input.isTouched()) {
                level7.setActive(true);
                if (saveData.getBoolean("effects")) {
                    click.play();
                }
                gameStateManager.push(new TetrisState(gameStateManager));
            }
        }
        else {
            back.setActive(false);
            for (int i = 0; i < this.buttons.size()-1; i++) {
                Button button = this.buttons.get(i);
                if (button.mouseInRegion() && !button.isLocked()) {
                    button.setActive(true);
                    if (Gdx.input.isTouched()) {
                        if (saveData.getBoolean("effects")) {
                            honk.play();
                        }
                        gameStateManager.push(new PlayState(gameStateManager, i + 1));
                    }
                } else {
                    button.setActive(false);
                }
            }
        }
    }

    /**
     * Updates the game logic before the next render() is called. In this instance the update method checks the game
     * save and unlocks level buttons accordingly.
     * @param deltaTime the amount of time which has passed since the last render() call
     */
    @Override
    public void update(float deltaTime) {

        handleInput();

        if(saveData.getBoolean("1")) {
            level1.setOnTexture(new Texture("PressedGreen1.png"));
            level1.setOffTexture(new Texture("NotPressedGreen1.png"));

            level2.setLocked(false);
            level2.setOnTexture(new Texture("PressedBlue2.png"));
            level2.setOffTexture(new Texture("NotPressedBlue2.png"));
        }

        if(saveData.getBoolean("2")) {
            level2.setOnTexture(new Texture("PressedGreen2.png"));
            level2.setOffTexture(new Texture("NotPressedGreen2.png"));

            level3.setLocked(false);
            level3.setOnTexture(new Texture("PressedBlue3.png"));
            level3.setOffTexture(new Texture("NotPressedBlue3.png"));
        }

        if(saveData.getBoolean("3")) {
            level3.setOnTexture(new Texture("PressedGreen3.png"));
            level3.setOffTexture(new Texture("NotPressedGreen3.png"));

            level4.setLocked(false);
            level4.setOnTexture(new Texture("MazePressed.png"));
            level4.setOffTexture(new Texture("MazeNotPressed.png"));
        }

        if(saveData.getBoolean("4")) {
            level4.setOnTexture(new Texture("MazePressedGreen.png"));
            level4.setOffTexture(new Texture("MazeNotPressedGreen.png"));

            level5.setLocked(false);
            level5.setOnTexture(new Texture("CliffordPressed.png"));
            level5.setOffTexture(new Texture("CliffordNotPressed.png"));
        }

        if(saveData.getBoolean("5")) {
            level5.setOnTexture(new Texture("CliffordPressedGreen.png"));
            level5.setOffTexture(new Texture("CliffordNotPressedGreen.png"));

            level6.setLocked(false);
            level6.setOnTexture(new Texture("RacecoursePressed.png"));
            level6.setOffTexture(new Texture("RacecourseNotPressed.png"));
        }

        if(saveData.getBoolean("6")) {
            level6.setOnTexture(new Texture("RacecoursePressedGreen.png"));
            level6.setOffTexture(new Texture("RacecourseNotPressedGreen.png"));
        }
    }

    /**
     * Used to draw elements onto the screen.
     * @param spriteBatch a container for all elements which need rendering to the screen
     */
    @Override
    public void render(SpriteBatch spriteBatch) {
        spriteBatch.begin();
        spriteBatch.draw(background, 0, 0, Kroy.WIDTH, Kroy.HEIGHT);
        spriteBatch.draw(back.getTexture(), back.getPosition().x, back.getPosition().y, back.getWidth(), back.getHeight());
        for (Button level : buttons) {
            spriteBatch.draw(level.getTexture(), level.getPosition().x, level.getPosition().y, level.getWidth(), level.getHeight());
        }
        spriteBatch.end();
    }

    /**
     * Used to dispose of all textures, music etc. when no longer required to avoid memory leaks
     */
    @Override
    public void dispose() {
        background.dispose();
        for (Button button : buttons) {
            button.dispose();
        }
        click.dispose();
        honk.dispose();
    }
}
